#!/bin/bash
while test $# -gt 0; do
        case "$1" in
                -h|--help)
                        echo "$PACKAGE - Initialize config"
                        echo " "
                        echo "$PACKAGE [options]"
                        echo " "
                        echo "options:"
                        echo "-h, --help                    Show brief help"
                        echo "-privateKey                   PrivateKey"
                        echo "-drop,                        Drop DB: 1, Keep DB: 0"
                        exit 0
                        ;;
                -privateKey)
                        shift
                        PRIVATE_KEY=$1
                        if [[ -z ${PRIVATE_KEY} ]]; then
                          echo "PrivateKey is not specified. Please fill the privateKey."
                          exit 1
                        fi
                        shift
                        ;;
                -drop)
                        shift
                        if test $# -ge 0; then
                            LEVELDB_DROP=$1
                            re='^[0-9]+$'
                            if ! [[ ${LEVELDB_DROP} =~ $re ]] ; then
                               echo "Drop db is not a number"
                               exit 1
                            fi
                        else
                            echo "Drop db is not specified"
                            exit 1
                        fi
                        shift
                        ;;
                *)
                        break
                        ;;
        esac
done

if [[ ! -z ${PRIVATE_KEY} ]]; then
    echo PRIVATE_KEY: ${PRIVATE_KEY}
    sed -i.bak "s/PrivateKey:.*/PrivateKey: ${PRIVATE_KEY}/g" ./kai_config.yaml
else
    echo "PrivateKey is not specified. Please fill the privateKey."
    exit 1
fi

if [[ -n ${LEVELDB_DROP} ]]; then
    echo DROPDB: ${LEVELDB_DROP}
    if [[ ${LEVELDB_DROP} -eq 1 ]]; then
        sed -i.bak "s/Drop:.*/Drop: 1/g" ./kai_config.yaml
    else
        sed -i.bak "s/Drop:.*/Drop: 0/g" ./kai_config.yaml
    fi
fi