# Prerequisites
Install Docker following the installation guide for Linux OS: [https://docs.docker.com/engine/installation/](https://docs.docker.com/engine/installation/)
* [CentOS](https://docs.docker.com/install/linux/docker-ce/centos) 
* [Ubuntu](https://docs.docker.com/install/linux/docker-ce/ubuntu)

Install docker compose
* [Docker compose](https://docs.docker.com/compose/install/)

## Preparation 
* Run the following command to config the node private key
```
 ./config.sh -privateKey <private key without 0x prefix>
```

Or use text editor to change the private key in `kai_config.yaml` (eg: nano, vim...) 
```
  PrivateKey: <privateKey>
``` 

* Optional: change your node name as displayed on p2p network

```
  Name: <node name>
```

## Join Mainnet
```
docker-compose up -d
``` 

### Check if container is running
```
docker-compose ps
```

### Logging
````
docker logs -f --tail 10 kai-mainnet-node
````
for last 10 logs line then follow up